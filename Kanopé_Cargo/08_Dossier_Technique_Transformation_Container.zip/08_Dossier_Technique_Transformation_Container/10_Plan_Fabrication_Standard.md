# 📐 Plan de Fabrication Standard – Kanopé Cargo

> Cette fiche présente une synthèse technique du container type aménagé, avec plans simplifiés, coupes, éléments structurels et liste indicative des composants nécessaires à la fabrication.

---

## 1️⃣ Schéma d’implantation (vue 2D simplifiée)

```text
┌────────────────────────────────────────────┐
│  Espace Nuit   |   Entrée / Cuisine   |  Séjour  │
│   (3,5 m)      |      (2,5 m)         |  (5,5 m) │
└────────────────────────────────────────────┘
```

- Entrée latérale au centre
- Baie vitrée en fond séjour
- Fenêtre côté cuisine et chambre
- Salle d’eau intégrée en cloison (compacte)

---

## 2️⃣ Liste des modules structurels

| Élément               | Type ou format                  |
|------------------------|----------------------------------|
| Container de base      | 40’ High Cube (12,19 × 2,44 m)   |
| Découpe baie vitrée    | 160 × 200 cm + renfort cadre     |
| Découpe fenêtre cuisine| 60 × 80 cm + renfort             |
| Découpe fenêtre nuit   | 100 × 80 cm                      |
| Porte latérale         | 90 × 215 cm                      |
| Renforts structure     | Cornières acier + soudures       |

---

## 3️⃣ Composants intérieurs principaux

| Équipement              | Quantité | Détail                                    |
|--------------------------|----------|-------------------------------------------|
| Meuble cuisine           | 1        | Frigo top, 2 plaques, évier inox          |
| Table murale rabattable | 1        | Bois ou panneau pliable                   |
| Lit 120 cm ou banquette | 1        | Avec rangement intégré                    |
| Placards hauts           | 3–4 ml   | Toute longueur                            |
| Douche 80x80             | 1        | Receveur extra-plat ou bac                |
| WC compact               | 1        | Standard ou suspendu                      |
| Vasque + meuble          | 1        | 40–60 cm avec miroir                      |

---

## 4️⃣ Matériaux principaux (indicatif)

| Élément               | Matériau                        | Surface approx. |
|------------------------|----------------------------------|------------------|
| Isolation mur/plafond  | Métisse / ouate cellulose        | ≈ 60 m²          |
| Sol                    | OSB + lino ou parquet            | ≈ 28 m²          |
| Pare-vapeur            | Film hygro-régulant              | ≈ 60 m²          |
| Parement intérieur     | OSB peint ou panneaux bois       | ≈ 60 m²          |
| Cloisons légères       | OSB + tasseaux bois              | 5–8 m linéaires  |

---

## 5️⃣ Outils & étapes

| Phase                      | Moyens                        |
|----------------------------|-------------------------------|
| Préparation structure      | Meuleuse, plasma, soudure MIG |
| Isolation et doublage      | Scie circulaire, visseuse     |
| Plomberie / élec / VMC     | Gaines, PER, tableau modulaire|
| Pose des menuiseries       | Mastic, mousse PU, niveau     |
| Finitions & contrôle final | Test électrique + étanchéité  |

---

## 6️⃣ Durée indicative d’aménagement (1 unité)

| Étape                        | Durée estimée (2 pers) |
|------------------------------|--------------------------|
| Structure & ouvertures       | 2–3 jours                |
| Isolation & cloisonnement    | 3 jours                  |
| Équipement technique         | 2 jours                  |
| Finitions & ameublement      | 2–3 jours                |
| Contrôle & livraison         | 1 jour                   |

---

## 🔗 Voir aussi

- [[04_Aménagement_Interieur]]
- [[09_Transport_&_Pose]]
- [[03_Isolation_&_Structure]]
