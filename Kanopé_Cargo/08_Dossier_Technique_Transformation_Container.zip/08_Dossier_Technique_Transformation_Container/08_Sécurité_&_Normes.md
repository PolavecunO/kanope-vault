# 🛡️ Sécurité & Normes – Kanopé Cargo

> Cette fiche réunit les principes de sécurité, les normes techniques et réglementaires à respecter pour transformer un container en logement habitable, sain, conforme et durable.

---

## 1️⃣ Incendie

| Élément                      | Recommandation                             |
|------------------------------|--------------------------------------------|
| 🔥 Matériaux de cloisonnement| Classement feu minimum M1 (faible inflammabilité) |
| 🚨 Détecteur de fumée        | Obligatoire (norme NF EN 14604)            |
| 🚒 Extincteur (option)       | Recommandé dans parties communes ou coliving |
| 💨 Ventilation               | Renouvellement d’air minimum réglementaire |

---

## 2️⃣ Ventilation et qualité de l’air

| Zone         | Obligation                     |
|---------------|--------------------------------|
| Salle d’eau   | Extraction directe obligatoire |
| Cuisine       | Hotte filtrante ou extraction  |
| VMC           | Simple ou double flux conforme |
| Transferts    | Grilles hautes / basses en cloison |

💡 Prévoir un renouvellement d’air de 15–30 m³/h selon pièce.

---

## 3️⃣ Normes d’habitabilité

| Critère                        | Seuil minimum réglementaire (France) |
|--------------------------------|--------------------------------------|
| Hauteur sous plafond           | ≥ 2,20 m                             |
| Surface habitable              | ≥ 9 m² (studio 1 pers)               |
| Volume habitable               | ≥ 20 m³                              |
| Ouvertures extérieures         | ≥ 1/6e de la surface habitable       |
| Équipements sanitaires         | WC, douche, lavabo                  |
| Ventilation                    | Conforme à la RT existant / RE2020   |

---

## 4️⃣ PMR (accessibilité personnes à mobilité réduite)

- Un container PMR doit proposer :
  - Porte d’entrée ≥ 90 cm
  - Aire de retournement de 1,5 m de diamètre
  - Douche à l’italienne sans ressaut
  - WC accessible et barre d’appui

📐 Voir modèle Kanopé [[Module_PMR]] pour exemple

---

## 5️⃣ Conformité urbanisme

| Élément                | Points de vigilance                      |
|------------------------|------------------------------------------|
| 📍 PLU / POS            | Vérifier emprise au sol, hauteur max, stationnement |
| 🏠 Déclaration          | Déclaration préalable ou permis de construire selon cas |
| 🔌 Raccordement réseaux| EAU / ÉLEC / ASSAINISSEMENT              |
| 📏 Zonage               | Urbain, agricole, constructible ou non   |

---

## 6️⃣ Gestion des risques naturels

- Respect du **PPRN** (Plan de prévention des risques naturels)
- Zones inondables : surélévation, ancrage renforcé
- Zones sismiques : liaison fondation / container certifiée
- Zones feu : bardage ininflammable, débroussaillage

---

## 🔗 Voir aussi

- [[09_Transport_&_Pose]]
- [[10_Plan_Fabrication_Standard]]
- [[05_Équipements_Techniques]]
